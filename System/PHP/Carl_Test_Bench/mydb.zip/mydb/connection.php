<?php
$server = "localhost";
$username = "root";
$password = "";
$db = "mydb";

$connect = new mysqli ($server,$username,$password,$db);
?>